/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package gestionclinica;


import DBAccess.ClinicDBAccess;
import java.io.File;
import java.net.URL;
import java.util.ArrayList;
import java.util.ResourceBundle;
import javafx.collections.FXCollections;
import javafx.collections.ObservableList;
import javafx.event.ActionEvent;
import javafx.fxml.FXML;
import javafx.fxml.Initializable;
import javafx.scene.control.Alert;
import javafx.scene.control.Button;
import javafx.scene.control.Label;
import javafx.scene.control.TextField;
import javafx.scene.image.Image;
import javafx.stage.FileChooser;
import javafx.stage.FileChooser.ExtensionFilter;
import javafx.stage.Stage;
import model.Patient;


/**
 * FXML Controller class
 *
 * @author Carlos
 */
public class FXMLPacientesAddController implements Initializable {

    @FXML
    private Button cancelButton;
    @FXML
    private TextField dniTextField;
    @FXML
    private TextField nombreTextField;
    @FXML
    private TextField apellidosTextField;
    @FXML
    private TextField telefonoTextField;
    @FXML
    private Button guardarButton;
    @FXML
    private Label selArchivoLabel;
    @FXML
    private Button salirButton;
    
    ArrayList<Patient> listaPacientes;
    
    Image img = null;
    
    static boolean guardado = false;
    
    
    
    /**
     * Initializes the controller class.
     */
    @Override
    public void initialize(URL url, ResourceBundle rb) {
        
        if(FXMLPacientesMainController.editable == false){
            dniTextField.setEditable(false);
            nombreTextField.setEditable(false);
            apellidosTextField.setEditable(false);
            telefonoTextField.setEditable(false);
            salirButton.setVisible(true);
            cancelButton.setVisible(false);
            guardarButton.setVisible(false);
            
            dniTextField.setText(FXMLPacientesMainController.current.getIdentifier());
            nombreTextField.setText(FXMLPacientesMainController.current.getName());
            apellidosTextField.setText(FXMLPacientesMainController.current.getSurname());
            telefonoTextField.setText(FXMLPacientesMainController.current.getTelephon());
            
        }else{
        salirButton.setVisible(false);
        cancelButton.setVisible(true);
        guardarButton.setVisible(true);
        }
        

    }    
    
   
    public void start(Stage primaryStage) {
          primaryStage.setTitle("JavaFX App");

        FileChooser fileChooser = new FileChooser();
    }
    

    @FXML
    private void guardarAct(ActionEvent event) {
        if (dniTextField.getText().isEmpty()){
            Alert alertAmazon = new Alert(Alert.AlertType.INFORMATION);
            alertAmazon.setTitle("Faltan datos");
            alertAmazon.setHeaderText("Por favor, introduce el DNI");
            alertAmazon.setContentText("No se puede guardar el paciente si no introduce el número de identificación personal");
            alertAmazon.showAndWait();
        } else if(nombreTextField.getText().isEmpty()){
            Alert alertAmazon = new Alert(Alert.AlertType.INFORMATION);
            alertAmazon.setTitle("Faltan datos");
            alertAmazon.setHeaderText("Por favor, introduce el nombre");
            alertAmazon.setContentText("No se puede guardar el paciente si no introduce el nombre");
            alertAmazon.showAndWait();
        }else if(apellidosTextField.getText().isEmpty()){
            Alert alertAmazon = new Alert(Alert.AlertType.INFORMATION);
            alertAmazon.setTitle("Faltan datos");
            alertAmazon.setHeaderText("Por favor, introduce los apellidos");
            alertAmazon.setContentText("No se puede guardar el paciente si no introduce los apellidos");
            alertAmazon.showAndWait();
        }else if(telefonoTextField.getText().isEmpty()){
            Alert alertAmazon = new Alert(Alert.AlertType.INFORMATION);
            alertAmazon.setTitle("Faltan datos");
            alertAmazon.setHeaderText("Por favor, introduce el teléfono");
            alertAmazon.setContentText("No se puede guardar el paciente si no introduce el teléfono");
            alertAmazon.showAndWait();
        }else{
            Patient nuevoPaciente = new Patient(dniTextField.getText(), nombreTextField.getText(), apellidosTextField.getText(), telefonoTextField.getText(), img);
            Stage stage = (Stage) cancelButton.getScene().getWindow();
            stage.close();
            ClinicDBAccess clinicDBAccess = ClinicDBAccess.getSingletonClinicDBAccess();
            ObservableList<Patient> patientsObservableList;
            patientsObservableList = FXCollections.observableList(clinicDBAccess.getPatients());
            patientsObservableList.add(nuevoPaciente);
            //clinicDBAccess.saveDB();
            guardado = true;
        }
               
        
        
        
    }

    @FXML
    private void CancelAct(ActionEvent event) {
        Stage stage = (Stage) cancelButton.getScene().getWindow();
        stage.close();
        guardado = false;
    }

    @FXML
    private void fotoAct(ActionEvent event) {
        FileChooser fileChooser = new FileChooser();
        fileChooser.setTitle("Open Resource File");
        fileChooser.getExtensionFilters().addAll(
        new ExtensionFilter("Image Files", "*.png", "*.jpeg","*.jpg", "*.gif"));
        File selectedFile = fileChooser.showOpenDialog(null);
        /*if (selectedFile != null) {
        selArchivoLabel.setText(selectedFile.getAbsolutePath());
        }*/
        img = new Image(selectedFile.toURI().toString());
    }
}

    
    

